import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-chooser',
  templateUrl: './widget-chooser.component.html',
  styleUrls: ['./widget-chooser.component.css']
})
export class WidgetChooserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
