import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-new',
  templateUrl: './page-new.component.html',
  styleUrls: ['./page-new.component.css']
})
export class PageNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
