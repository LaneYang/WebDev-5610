import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-website-new',
  templateUrl: './website-new.component.html',
  styleUrls: ['./website-new.component.css']
})
export class WebsiteNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
